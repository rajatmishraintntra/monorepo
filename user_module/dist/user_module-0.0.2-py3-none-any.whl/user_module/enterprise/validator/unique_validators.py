class UniqueValidator:
    def validate(self, data):
        """
        @param data: value
        @return:
        """
        if data:
            return False
        else:
            return True
