class UniqueValidator:
    pass
