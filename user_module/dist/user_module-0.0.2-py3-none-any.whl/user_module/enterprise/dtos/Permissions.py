from user_module.business.entities.permissions import AbstractPermissions


class PermissionsDTO(AbstractPermissions):
    pass
