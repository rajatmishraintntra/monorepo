from user_module.business.entities.role import AbstractRole


class RoleDTO(AbstractRole):
    pass
